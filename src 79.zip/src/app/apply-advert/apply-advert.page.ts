import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-apply-advert',
  templateUrl: './apply-advert.page.html',
  styleUrls: ['./apply-advert.page.scss'],
})
export class ApplyAdvertPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
