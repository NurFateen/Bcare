export interface Category{
    title: string;
    image: string;
}