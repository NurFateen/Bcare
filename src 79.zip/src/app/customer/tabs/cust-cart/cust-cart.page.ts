import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cust-cart',
  templateUrl: './cust-cart.page.html',
  styleUrls: ['./cust-cart.page.scss'],
})
export class CustCartPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
