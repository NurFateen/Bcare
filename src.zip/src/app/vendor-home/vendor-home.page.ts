import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vendor-home',
  templateUrl: './vendor-home.page.html',
  styleUrls: ['./vendor-home.page.scss'],
})
export class VendorHomePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
