import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upload-form',
  templateUrl: './upload-form.page.html',
  styleUrls: ['./upload-form.page.scss'],
})
export class UploadFormPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
