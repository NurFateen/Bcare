import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cust-editprofile',
  templateUrl: './cust-editprofile.page.html',
  styleUrls: ['./cust-editprofile.page.scss'],
})
export class CustEditprofilePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
