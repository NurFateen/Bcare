export class Customer {
    constructor(
        public id: string,
        public email: string,
        public fullName: string,
        public phoneNum: number,
        public address: string,
        public country: string) { }
}
