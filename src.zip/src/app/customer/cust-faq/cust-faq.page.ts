import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cust-faq',
  templateUrl: './cust-faq.page.html',
  styleUrls: ['./cust-faq.page.scss'],
})
export class CustFaqPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
