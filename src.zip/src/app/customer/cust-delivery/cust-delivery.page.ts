import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cust-delivery',
  templateUrl: './cust-delivery.page.html',
  styleUrls: ['./cust-delivery.page.scss'],
})
export class CustDeliveryPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
