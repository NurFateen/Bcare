import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cust-feedback',
  templateUrl: './cust-feedback.page.html',
  styleUrls: ['./cust-feedback.page.scss'],
})
export class CustFeedbackPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
