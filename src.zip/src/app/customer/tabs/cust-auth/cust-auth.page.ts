import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cust-auth',
  templateUrl: './cust-auth.page.html',
  styleUrls: ['./cust-auth.page.scss'],
})
export class CustAuthPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
