import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cust-homepage',
  templateUrl: './cust-homepage.page.html',
  styleUrls: ['./cust-homepage.page.scss'],
})
export class CustHomepagePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
