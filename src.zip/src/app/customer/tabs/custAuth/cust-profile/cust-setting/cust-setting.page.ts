import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cust-setting',
  templateUrl: './cust-setting.page.html',
  styleUrls: ['./cust-setting.page.scss'],
})
export class CustSettingPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
