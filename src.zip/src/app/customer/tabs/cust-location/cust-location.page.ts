import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cust-location',
  templateUrl: './cust-location.page.html',
  styleUrls: ['./cust-location.page.scss'],
})
export class CustLocationPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
