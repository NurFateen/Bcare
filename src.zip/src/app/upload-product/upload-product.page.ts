import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upload-product',
  templateUrl: './upload-product.page.html',
  styleUrls: ['./upload-product.page.scss'],
})
export class UploadProductPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
