import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-yourplan',
  templateUrl: './yourplan.page.html',
  styleUrls: ['./yourplan.page.scss'],
})
export class YourplanPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
